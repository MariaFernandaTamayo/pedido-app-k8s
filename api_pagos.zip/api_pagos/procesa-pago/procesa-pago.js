const express = require("express");
const app = express();

app.get("/procesa", (req, res) => {
  const { uuid } = req.query;
  console.log("Procesando pago con UUID:", uuid);

  res.json({
    uuid,
    estado: "Procesado"
  });
});

app.listen(9090, () => {
  console.log("Procesa Pago escuchando en 9090");
});
