const express = require("express");
const axios = require("axios");
const { v4: uuidv4 } = require("uuid");

const app = express();
app.use(express.json());

app.post("/pago", async (req, res) => {
  const { monto, producto } = req.body;

  if (!monto || !producto) {
    return res.status(400).json({ error: "Datos incompletos" });
  }

  // 1️⃣ Generar UUID
  const uuid = uuidv4();
  console.log("UUID generado:", uuid);

  // 2️⃣ Llamada INTERNA por cluster
  try {
    await axios.get(
      `http://procesa-pago:9090/procesa?uuid=${uuid}`
    );
  } catch (error) {
    console.error("Error llamando a procesa-pago");
  }

  // 3️⃣ Respuesta al cliente
  res.json({
    uuid,
    mensaje: "Pago recibido"
  });
});

app.listen(8080, () => {
  console.log("Pago API escuchando en 8080");
});
